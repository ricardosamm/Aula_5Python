# len = comprimento (quantidade)

# nome_da_cidade = 'Guarulhos'
# comprimento = len(nome_da_cidade)
# print(comprimento)

# dia_da_semana = 'sabado'
# print(len(dia_da_semana))

# x = 4
# print(type(x))

# x = 'terra'
# dado = x
# print(type(dado))

# z = '45'
# n = float(z)
# print(int(z))
# print(n+5)

# cidade = 'Guarulhos'
# print(cidade, '\n')
# frag = list(cidade)
# print(frag)

# tr = tuple(frag)
# print(tr)

# numero = range(1,11,2)
# print(numero)

# n = range (1,3)
# print(n)

# lista = [1,6,812,0,45]
# soma = sum(lista)
# print('a soma de tudo é', soma)

# lista = [100,36,145,1]
# maxi = max(lista)
# print(maxi)

# lista = [100,36,145,1]
# mini = min(lista)
# print(mini)

# lista = [56,566,7878,15,1,0,89,10]
# organize = sorted(lista)
# print(organize)

# lista = ['a','e','r','g','b','y','t','j']
# organize = sorted(lista)
# print(organize)

# for i in range(1,51):
#     print(i)

# for n in range(1,13):
#   print(n)

# Exercício 1: Escreva um programa que use a função range() para gerar os números pares de 2 a 20 e, em seguida, imprima cada número.

# for i in range(2,22,2):
#   print(i)


# Exercício 2: Escreva um programa que use a função range() para gerar os múltiplos de 5 em 5 a 50 e, em seguida, calcule e imprima a soma desses múltiplos.

# for i in range(5,55,5):
#   print(i)
# lista = range (5,55,5)
# soma = sum(lista)
# print('a soma de tudo é', soma)


# Exercício 3: Escreva um programa que use a função type() para verificar o tipo de uma variável.

# x = 4
# print(type(x))

# Exercício 4: Escreva um programa que use a função print() para imprimir uma mensagem de saudação personalizada, incluindo o nome do usuário.

# nome = input('Digite seu nome: \n')
# print('Ola tudo bem', nome)

# Exercício 5: Escreva um programa que use a função range() para gerar os números ímpares de 1 a 10 e, em seguida, calcule e imprima a média desses números.

# for i in range(1,10,2):
#   print(i)
# lista = range(1,10,2)
# soma = sum(lista)
# print('A soma total é:', soma)
# comprimento = len(lista)
# media = soma/comprimento
# print('A soma total é:', int(media))

# palavra = 'python'
# for letra in palavra:
#   print(letra)

# lista = ['maçã', 'banana', 'cereja', 'uva']
# for i in lista:
#   print(i)

#Dicionario
# dados = {'nome': 'Julio','idade':18,'endereco': 'rua 10'}
# for i1 , i2 in dados.items():
#   print(f'{i1} : {i2}')


# matriz = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

# # print(matriz[1][2])
# for i in matriz:
#    for n  in i:
#        print(i)